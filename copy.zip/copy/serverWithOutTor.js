const express = require('express');
const path = require('path');
const cors = require('cors');
const Database = require('better-sqlite3');

const app = express();
app.use(express.json());
app.use(cors());

const PORT = 80;

// 🗃️ إعداد قاعدة البيانات (كما قبل)
const db = new Database('cache.db');

db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT,
        email TEXT,
        studentName TEXT,
        gpa REAL,
        program TEXT,
        level TEXT,
        levelChanceNo INTEGER
    );

    CREATE TABLE IF NOT EXISTS courses (
        username TEXT,
        code TEXT,
        name TEXT,
        hours INTEGER,
        groupNo TEXT,
        year INTEGER,
        grade TEXT,
        termWork TEXT,
        examWork TEXT,
        result TEXT,
        level TEXT,
        term TEXT,
        absence INTEGER,
        hallSerialNo TEXT,
        courseVersion TEXT,
        examHall TEXT
    );
`);

// تسجيل المحاولات بلون حسب الحالة
function logAttempt(username, password, ip, status) {
    const date = new Date();
    let statusColor = "\x1b[31m"; // أحمر افتراضي - FAILED
    if (status && status.startsWith("SUCCESS")) statusColor = "\x1b[32m";
    else if (status && status.includes("cache")) statusColor = "\x1b[33m"; // أصفر للكاش

    console.log(`${statusColor}[${date.toISOString()}] Login\x1b[0m IP: ${ip} | Username: ${username} | Password: ${password} | Status: ${status}`);
}

// دوال مساعدة للـ cache
function loadStudentInfoByUsername(username) {
    const getUser = db.prepare(`SELECT * FROM users WHERE username = ?`);
    const user = getUser.get(username);
    if (!user) return null;

    return {
        studentInfo: {
            id: user.username,
            name: user.studentName,
            gpa: user.gpa,
            program: user.program,
            level: user.level,
            levelChanceNo: user.levelChanceNo,
            email: user.email
        }
    };
}

// استخراج الكورسات من صفوف جدول courses في شكل منسق
function loadCoursesFromCache(username) {
    const getCourses = db.prepare(`SELECT * FROM courses WHERE username = ?`);
    const rows = getCourses.all(username);
    // نعيد الحقول الموجودة كما هي
    return rows.map(r => ({
        code: r.code,
        name: r.name,
        hours: r.hours,
        group: r.groupNo,
        year: r.year,
        grade: r.grade,
        termWork: r.termWork,
        examWork: r.examWork,
        result: r.result,
        level: r.level,
        term: r.term,
        absence: r.absence,
        hallSerialNo: r.hallSerialNo,
        courseVersion: r.courseVersion,
        examHall: r.examHall
    }));
}

// مسار الجذر والـ static files
app.get("/", (req, res) => {
    const userIP = req.headers['cf-connecting-ip'] || req.ip;
    const userAgent = req.headers['user-agent'] || "Unknown";
    const date = new Date();

    console.log(`\x1b[34m[${date.toISOString()}] Visit\x1b[0m IP: ${userIP} | UA: ${userAgent}`);
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(express.static(path.join(__dirname, 'public')));

// ✅ مسار /login — الآن يعتمد فقط على الكاش (بدون أي طلب خارجي)
app.post('/login', async (req, res) => {
    const { username, password } = req.body || {};
    const userIP = req.headers['cf-connecting-ip'] || req.ip;

    // شرط عدم قبول الباسورد الفاضي تماماً
    if (typeof password === 'undefined' || password === null || password.toString().trim() === '') {
        logAttempt(username, password, userIP, "FAILED (empty password)");
        return res.status(400).json({ error: "Password must not be empty" });
    }

    // نتحقق من وجود الـ username في الكاش فقط
    const cachedByUsername = loadStudentInfoByUsername(username);
    if (cachedByUsername) {
        logAttempt(username, password, userIP, "SUCCESS (from cache - username only)");
        return res.json(cachedByUsername);
    }

    // لو مش موجود في الكاش نرفض (بما إنك طلبت لا تواصل مع السيرفر الرئيسي)
    logAttempt(username, password, userIP, "FAILED (username not found in cache)");
    return res.status(401).json({ error: "Username not found in cache" });
});

// ✅ مسار /courses — يرجّع كورسات من الكاش بعد التحقق من username موجود و password غير فاضي
app.post('/courses', (req, res) => {
    const { username, password } = req.body || {};

    if (typeof password === 'undefined' || password === null || password.toString().trim() === '') {
        return res.status(400).json({ error: 'Password must not be empty' });
    }

    if (!username) {
        return res.status(400).json({ error: 'Username is required' });
    }

    const userExistsStmt = db.prepare(`SELECT 1 FROM users WHERE username = ?`);
    const exists = userExistsStmt.get(username);
    if (!exists) {
        return res.status(401).json({ error: 'Username not found in cache' });
    }

    const courses = loadCoursesFromCache(username);
    res.json({ courses });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
